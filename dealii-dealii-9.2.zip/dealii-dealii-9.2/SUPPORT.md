In case of questions
====================

There are many ways to obtain support if you have questions about deal.II.
Please see the [main project website](https://dealii.org/) for links to the
web forum, links to the documentation, and much other information.
