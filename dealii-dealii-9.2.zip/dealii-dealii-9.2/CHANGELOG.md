Changes to deal.II between versions
===================================

The list of changes between versions of deal.II is maintained as part of the
regular documentation. You can find it
[here](https://www.dealii.org/developer/doxygen/deal.II/pages.html).